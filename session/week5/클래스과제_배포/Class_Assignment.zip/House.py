class House:
    def __init__(self,size,rooms):
        self.size=int(size)
        self.rooms=int(rooms)
